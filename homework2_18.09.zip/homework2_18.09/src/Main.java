import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //
        //Необходимо суммировать все нечётные целые числа в диапазоне,
        // введённом пользователем.
        // Программу повторять, пока пользователь не введёт «quit».
        Scanner scr = new Scanner(System.in);
        System.out.println("Введи первое целое число: ");
        int num1 = scr.nextInt();
        System.out.println("Введи второе целое число: ");
        int num2 = scr.nextInt();scr.nextLine();
        int min = Math.min(num1,num2);
        int max = Math.max(num1,num2);
        int summa = 0;
        String str = "";
        do {
            for (int i = min; i <= max; i++) {
                if (i %2 != 0){
                    summa += i;
                }

            }
            System.out.println(summa);
            System.out.println("Введи \"quit\" для выхода из этой программы ");
            str = scr.nextLine();
        }while (!"quit".equalsIgnoreCase(str));

        }
    }
