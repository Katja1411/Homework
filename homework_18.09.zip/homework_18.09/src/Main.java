import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Задание 1
        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить
        //тебе одну купюру номиналом 50, 100, 200 или 500 долларов.
        // Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        // останавливай сбор подарков и веди всех выпить за твоё здоровье
        // в лучший бар города!

        Random rnd = new Random();
        int a = 50;
        int b = 100;
        int c = 200;
        int d = 500;
        int summa = 0;
        int newPc = 10000;
        while (summa < newPc) {
            int rndChoice = rnd.nextInt(0, 5);
            switch (rndChoice) {
                case 1 -> summa += a;
                case 2 -> summa += b;
                case 3 -> summa += c;
                default -> summa += d;
            }
            System.out.println("Спасибо, у меня уже: " + summa + " мне осталось: " + (newPc - summa));
        }
        System.out.println("Ура! Пойдём в бар!");


    }
}

