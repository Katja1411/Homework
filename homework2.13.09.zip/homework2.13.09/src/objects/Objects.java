package objects;

public enum Objects {
    STONE,
    SCISSORS,
    PAPER
}
