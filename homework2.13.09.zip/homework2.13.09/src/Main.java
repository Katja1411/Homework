import objects.Objects;

import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

import static objects.Objects.*;

public class Main {
    public static void main(String[] args) {
        //Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
        //свой выбор (в виде строки или числа). Программа случайным образом делает
        //свой выбор и выводит на экран. Далее программа показывает, кто победитель –
        //пользователь или программа

        System.out.println("Сыграем в камень, ножницы, бумага?");
        Scanner scr = new Scanner(System.in);
        do {
            System.out.println("Набери stone, scissors или paper: ");
            System.out.println("Выбери  No чтобы закончить игру");

            String name = scr.nextLine().toUpperCase(Locale.ROOT);
            Objects userTurn = Objects.valueOf(name);

            Random rnd = new Random();
            int compNumber = rnd.nextInt(0, 3);
            Objects compTurn = switch (compNumber) {
                case 0 -> PAPER;
                case 1 -> SCISSORS;
                default -> STONE;
            };

            System.out.println(compTurn);
            if (compTurn == userTurn) {
                System.out.println("Ничья!");
            } else {
                if (userTurn == PAPER && compTurn == STONE ||
                        userTurn == STONE && compTurn == SCISSORS ||
                        userTurn == SCISSORS && compTurn == PAPER) {
                    System.out.println("Ты победил!");
                } else {
                    System.out.println("Ты проиграл!");

                }
            }

            System.out.println("Поиграешь ещё раз?");
        }while (!"No".equalsIgnoreCase(scr.nextLine()));
    }
}