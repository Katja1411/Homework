import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
// которую дал покупатель. Выведите
//сумму сдачи в виде “X рублей и Y копеек”.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите стоимость покупок:  ");
        double price = scr.nextDouble();
        System.out.println("Введите стоимость полученных денег к оплате: ");
        double cash = scr.nextDouble();
        double change = price - cash;
        double Euro = (int)change;
        double Cent = (change*100)%100;
        System.out.println("Сдача: " + Euro + "евро" + Cent + "центов");

    }
}