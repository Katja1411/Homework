import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");
        /*
        Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы,
         напишите программу, в которой пользователь вводит год.
         Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
         Если указанный пользователем год с 1935 по 1977 включительно,
         то вывести «Элвис жив!». Если введённый пользователем год больше 1977,
         то вывести «Элвис навсегда в наших сердцах!»
         */
        Scanner src = new Scanner(System.in);
        System.out.println("Введите, пожалуйста, год: ");
        int Year = src.nextInt();

        System.out.println(Year < 1935 ? "Элвис ещё не родился " : "");
        System.out.println(  1935 <= Year && Year <= 1977 ? "Элвис жив": "");
        System.out.println( Year > 1977 ? "Элвис навсегда в наших сердцах!" : "");

    }
}
