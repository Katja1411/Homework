import java.util.Scanner;

public class Main {
    public static void main (String[] args) {
        /*System.out.println("Hello world!");
        Дан (введён или сгенерирован) номер дня недели. Выведите название дня
          недели.
          Если номер дня введён некорректно, то выведите соответствующее
         сообщение и завершите программу
         */
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите число недели: ");
        int num = scr.nextInt();

        if (num==1) {
            System.out.println("Понедельник");
        }
        if (num==2){
            System.out.println("Вторник");
        }
        if (num==3){
            System.out.println("Среда");
        }
        if (num==4){
            System.out.println("Четверг");
        }
        if (num==5){
            System.out.println("Пятница");
        }
        if (num==6){
            System.out.println("Суббота");
        }
        if (num==7){
            System.out.println("Воскресенье");
        }else {
            System.out.println("Вы что-то не то задали");
        }

    }
}