import wedding.Weddingsname;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Сколько лет вы состоите в браке?");
        int index = scanner.nextInt();
        Weddingsname wedding = switch (index) {
            case 1 -> Weddingsname.CHINTZ_WEDDING;
            case 2 -> Weddingsname.PAPER_WEDDING;
            case 3 -> Weddingsname.LEATHER_WEDDING;
            case 4 -> Weddingsname.LINEN_WEDDING;
            case 5 -> Weddingsname.WOODEN_WEDDING;
            case 6 -> Weddingsname.CAST_IRON_WEDDING;
            case 7 -> Weddingsname.COOPER_WEDDING;
            case 8 -> Weddingsname.TIN_WEDDING;
            case 9 -> Weddingsname.EARTHENWARE_WEDDING;
            case 10 -> Weddingsname.PEWTER_WEDDING;
            case 11 -> Weddingsname.STEEL_WEDDING;
            case 12 -> Weddingsname.NIKEL_WEDDING;
            case 13 -> Weddingsname.LACE_WEDDING;
            case 14 -> Weddingsname.AGATE_WEDDING;
            case 15-> Weddingsname.CRYSTAL_WEDDING;
            default -> throw new RuntimeException("Вы состоите в браке больше 15 лет, вот это выдержка! ");
        };
        //System.out.println(wedding);
        String description = switch (wedding) {
            case CHINTZ_WEDDING -> "Ситцевая (марлевая) свадьба";
            case PAPER_WEDDING -> "Бумажная свадьба";
            case LEATHER_WEDDING ->"Кожаная свадьба";
            case LINEN_WEDDING ->"Льняная свадьба";
            case WOODEN_WEDDING -> "Деревянная свадьба";
            case CAST_IRON_WEDDING ->"Чугунная свадьба";
            case COOPER_WEDDING ->"Медная (Шерстяная) свадьба";
            case TIN_WEDDING ->"Жестяная свадьба";
            case EARTHENWARE_WEDDING ->"Фаянсовая (ромашковая) свадьба";
            case PEWTER_WEDDING ->"Оловянная свадьба";
            case STEEL_WEDDING ->"Стальная свадьба";
            case NIKEL_WEDDING ->"Никелевая свадьба";
            case LACE_WEDDING ->"Кружевная (ландышевая) свадьба";
            case AGATE_WEDDING ->"Агатовая свадьба";
            case CRYSTAL_WEDDING ->"Хрустальная (Стеклянная) свадьба";

        };
        System.out.println("Поздравляю, в следующем году у вас будет " + description);

    }
}