import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //System.out.println("Hello world!");
        Scanner src = new Scanner(System.in);
        System.out.println("Давайте проверим Ваши знания таблицы умножения. Введите, пожалуйста, первое целое число:");
        int num1 = src.nextInt();
        System.out.println("Спасибо. Теперь введите второе целое число");
        int num2 = src.nextInt();
        System.out.println("Итак, сколько же будет " + num1 + "*" + num2 + " ?");
        //int result= src.nextInt();
        //result = num1*num2;
        int result = num1*num2;
        int result2 = src.nextInt();
        if (result == result2){
            System.out.println("Всё верно, " + result );
        }else {
            System.out.println(result);
        }



    }
}