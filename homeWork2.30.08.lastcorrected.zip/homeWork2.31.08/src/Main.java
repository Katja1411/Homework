public class Main {
    public static void main(String[] args) {
      short numberOne = 345;
      short numberTwo = 115;
      short numberThree = 86;
      short numberFour = 69;
        System.out.println(numberOne);
        System.out.println(numberOne/numberTwo);
        System.out.println(numberOne/numberThree);
        System.out.println(numberOne/numberFour);

      short numberFive = 987;
        System.out.println(numberFive);
        System.out.println(numberFive/100);
        System.out.println((numberFive/10)%10);
        System.out.println(numberFive%10);

    }
}