import daysofweek.DaysOfWeek;

import java.time.DayOfWeek;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите день недели: ");
        String day = scr.nextLine();
        System.out.println("Все остальные дни: ");

        for (DaysOfWeek d : DaysOfWeek.values()) {
            d != day;

            System.out.println(d);


        }


        //for (DaysOfWeek d : DaysOfWeek.values()) {
        // if (Objects.equals(day, "Monday")) {
        //                if (d.equals(DaysOfWeek.MONDAY)) continue;
        //                System.out.println(d);
        //            } else if (Objects.equals(day, "Tuesday")) {
        //                if (d.equals(DaysOfWeek.TUESDAY)) continue;
        //                System.out.println(d);
        //
        //            } else if (Objects.equals(day, "Wednesday")) {
        //                if (d.equals(DaysOfWeek.WEDNESDAY)) continue;
        //                System.out.println(d);
        //
        //            } else if (Objects.equals(day, "Thursday")) {
        //                if (d.equals(DaysOfWeek.THURSDAY)) continue;
        //                System.out.println(d);
        //            } else if (Objects.equals(day, "Friday")) {
        //                if (d.equals(DaysOfWeek.FRIDAY)) continue;
        //                System.out.println(d);
        //            } else if (Objects.equals(day, "Saturday")) {
        //                if (d.equals(DaysOfWeek.SATURDAY)) continue;
        //                System.out.println(d);
        //            } else if (Objects.equals(day, "Sunday")) {
        //                if (d.equals(DaysOfWeek.SUNDAY)) continue;
        //                System.out.println(d);
        //            }

    }
}

