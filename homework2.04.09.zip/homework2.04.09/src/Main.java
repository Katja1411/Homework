import java.util.Scanner;

public class Main {
    public static void main (String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.print("Доброго времени суток, введите ваше имя:");
        String name = scr.nextLine();
        System.out.print(name + ", " + " сколько вам лет?");
        int age = scr.nextInt();
        System.out.print("Укажите, пожалуйста, ваш вес.");
        float weight = scr.nextFloat();
        System.out.print("Уважаемый," + name + " в свои " + age + "лет Вы для нас дороги, как " + weight + "килограмм золота.");
    }
}