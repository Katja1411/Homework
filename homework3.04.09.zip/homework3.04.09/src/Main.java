import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите первое целое число: ");
        int num1 = scanner.nextInt();

        System.out.print("Введите действие: ");
        String action = scanner.nextLine();
        action = scanner.nextLine();

        System.out.print("Введите второе число: ");
        int num2 = scanner.nextInt();

        int result;

        switch (action) {
            case "+":
                result = num1 + num2;
                System.out.println("Результат: " + result);
                break;

            case "-":
                result = num1 - num2;
                System.out.println("Результат: " + result);
                break;

            case "*":
                result = num1 * num2;
                System.out.println("Результат: " + result);
                break;

            case "/":
                if (num2 == 0 || num1 == 0)
                    System.out.println("На ноль делить нельзя!");
                else {
                    result = num1 / num2;
                    System.out.println("Результат: " + result);
                    break;
                }
                default:
                System.out.println("Вы что-то ввели не так");
        }


    }
}