public class Main {
    public static void main(String[] args) {
        char myChar = 'G';
        int myInt = 89;
        byte myByte = 4;
        short myShort = 56;
        float myFloat = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong = 12121L;
        System.out.println(myChar);
        System.out.println(myInt);
        System.out.println(myByte);
        System.out.println(myShort);
        System.out.println(myFloat);
        System.out.println(myDouble);
        System.out.println(myLong);
    }

}
