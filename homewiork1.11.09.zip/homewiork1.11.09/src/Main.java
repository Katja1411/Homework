import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Random rnd = new Random();
        float num1 = rnd.nextFloat(-20, 21);
        float num2 = rnd.nextFloat(-20, 21);
        //System.out.println(num1);
        //System.out.println(num2);
        float diffNum1 = Math.abs(num1 - 10);
        float diffNum2 = Math.abs(num2 - 10);
        if (diffNum1 < diffNum2) {
            System.out.println(num1);
        } else {
            System.out.println(num2);
        }

    }
}