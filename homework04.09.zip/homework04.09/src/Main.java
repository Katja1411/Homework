import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        short s = (short) rnd.nextInt();
        int num1 = rnd.nextInt();
        long num2 = rnd.nextLong();
        double num3 = rnd.nextDouble();
        float num4 = rnd.nextFloat();
        boolean boo = rnd.nextBoolean();
        char ch = (char) rnd.nextInt();

        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        System.out.println(b);
        System.out.println(s);
        System.out.println(boo);
        System.out.println(ch);

        int i2 = rnd.nextInt();
        String str = String.valueOf(i2);
        System.out.println(str);
        long lo = rnd.nextLong();
        System.out.println(lo);
        

    }
}