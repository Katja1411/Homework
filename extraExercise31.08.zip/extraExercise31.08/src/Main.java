public class Main {
    public static void main(String[] args) {
        int myInt = 2147483647;
        System.out.println(myInt);
        myInt = 2147483647 + 1;
        System.out.println(myInt);

        byte myByte = 127;
        float myFloat = 3.54f;
        System.out.println(myByte*myFloat);

        char myChar = 'A';
        System.out.println(myChar);
        myChar = 'A'+1;
        System.out.println(myChar);
Предположу, что char всё-таки не является числовым типом и в данном случае код рассмотрел команду +1 как повышение градации литеральной переменной, в данном случае переместил её по алфавиту на одну букву ниже
    }
}