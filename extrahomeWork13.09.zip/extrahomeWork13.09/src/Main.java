import com.sun.source.util.DocTreePathScanner;
import month.NameofMonths;

import java.time.Month;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner (System.in);
        System.out.println("Введите название месяца: ");
        String name = scr.nextLine();
        NameofMonths month = NameofMonths.valueOf(name.toUpperCase(Locale.ROOT));

        String season = switch (month){
            case DECEMBER, JANUARY, FEBRUARY -> "Зимний месяц";
            case MARCH, APRIL, MAY -> "Весенний месяц";
            case JUNE,JULY, AUGUST -> "Летний месяц";
            case SEPTEMBER, OCTOBER, NOVEMBER -> "Осенний месяц";
        };
        System.out.println(season);

        }

    }
